﻿//
//Message Organiser
//
//Reads message files, and then sorts the messagenames to create MessageID's for each message
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
using System.Text.RegularExpressions;

namespace MessageOrganiser
{
    class Program
    {
        static void Main(string[] args)
        {
            string filetoopen = System.IO.Path.GetFileName(@args[0]);
            string currentfolder = System.IO.Path.GetDirectoryName(@args[0]);
            string Messages = File.ReadAllText(filetoopen);

            int startPos = Messages.IndexOf(@"<ServiceID TYPE=""UBYT"">") + @"<ServiceID TYPE=""UBYT"">".Length;
            int length = Messages.IndexOf("</ServiceID>") - startPos;
            string svcid = Messages.Substring(startPos, length);

            startPos = Messages.IndexOf(@"<ProtocolType TYPE=""STR"">") + @"<ProtocolType TYPE=""STR"">".Length;
            length = Messages.IndexOf("</ProtocolType>") - startPos;
            string svcname = Messages.Substring(startPos, length);

            Messages = Regex.Replace(Messages, @"^((?!MsgName).)*$",string.Empty, RegexOptions.Multiline);
            Messages = Regex.Replace(Messages, @"<_MsgName TYPE=""STR"" NOXFER=""TRUE"">", string.Empty, RegexOptions.Multiline);
            Messages = Regex.Replace(Messages, @"</_MsgName>", string.Empty, RegexOptions.Multiline);
            Messages = Regex.Replace(Messages, " ", string.Empty, RegexOptions.Multiline);
            Messages = Regex.Replace(Messages, "\t", string.Empty, RegexOptions.Multiline);
            Messages = Regex.Replace(Messages, "\r\n\r\n", "\r\n", RegexOptions.Multiline);
            for (int i = 0; i < 5; i++)
                Messages = Regex.Replace(Messages, "\n\n", "\n", RegexOptions.Multiline);
            Messages = Regex.Replace(Messages, "^\n", string.Empty, RegexOptions.Multiline);

            string[] msglines = Messages.Split(new[] { '\n' });
            Array.Sort(msglines, (x, y) => String.Compare(x, y));

            string filename = svcid + "_" + svcname + ".txt";
            string output = filename;
            
            for(int i = 1; i< msglines.Length; i++)
            {
                output = output + "\n" + i + ": " + msglines[i];
            }

            File.WriteAllText(currentfolder + "\\" + filename, output);
        }
    }
}
